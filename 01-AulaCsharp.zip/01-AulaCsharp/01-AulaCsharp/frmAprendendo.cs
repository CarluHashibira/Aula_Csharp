﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _01_AulaCsharp
{
    public partial class frmAprendendo : Form
    {
        public frmAprendendo()
        {
            InitializeComponent();
        }

        private void btnOla_Click(object sender, EventArgs e)
        {
            // Caixa de mensagem: Mensagem, titulo, botão e icone
            MessageBox.Show("Olá humano, seja bem vindo(a)!", "Aviso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnAtencao_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Atenção!!!\nNão falte nas aulas de C#", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void btnCuidado_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cuidado!!!\nNão apague a System32", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
           
                Application.Exit();
            
        }

        private void frmAprendendo_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult Sair = MessageBox.Show("Deseja sair do programa?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Sair == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void chkSQL_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSQL.Checked == true)
            {
                MessageBox.Show("Você marcou SQL server", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Você desmarcou SQL server", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void chkCsharp_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCsharp.Checked == true)
            {
                MessageBox.Show("Você marcou C#", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Você desmarcou C#", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void chkMysql_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMysql.Checked == true)
            {
                MessageBox.Show("Você marcou MySQL", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Você desmarcou MySQL", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void rdbSim_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbSim.Checked == true)
            {
                MessageBox.Show("Boa Escolha", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
           
        }

        private void rdbNao_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbNao.Checked == true)
            {
                MessageBox.Show("Putz grila!!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
           
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txbSenha_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
